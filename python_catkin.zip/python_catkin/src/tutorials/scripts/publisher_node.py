import rospy
from geometry_msgs.msg import PoseStamped

rospy.init_node("mynode")

goal_publisher = rospy.Publisher("MarkerArray", PoseStamped, queue_size=400)

goal = PoseStamped()

goal.header.seq = 1
goal.header.stamp = rospy.Time.now()

goal.header.frame_id = "Arrow"
goal.pose.position.x = -10
goal.pose.position.y = -50
goal.pose.position.z = 1

for y in range(3, 20, 2):    
    goal.pose.position.y = goal.pose.position.y  + y
    rospy.sleep(0.2)
    goal_publisher.publish(goal)


goal.header.frame_id = "Cube"
goal.pose.position.x = -5
goal.pose.position.y = -50
goal.pose.position.z = 1

for y in range(3, 20, 2):    
    goal.pose.position.y = goal.pose.position.y  + y
    rospy.sleep(0.2)
    goal_publisher.publish(goal)

goal.header.frame_id = "Sphere"
goal.pose.position.x = 0
goal.pose.position.y = -50
goal.pose.position.z = 1

for y in range(3, 20, 2):    
    goal.pose.position.y = goal.pose.position.y  + y
    rospy.sleep(0.2)
    goal_publisher.publish(goal)

goal.pose.position.x = 5
goal.pose.position.y = -50
goal.pose.position.z = 1

for y in range(3, 20, 2):    
    goal.pose.position.y = goal.pose.position.y  + y
    rospy.sleep(0.15)
    goal.header.frame_id = "Arrow"
    goal_publisher.publish(goal)
    rospy.sleep(0.15)
    goal.header.frame_id = "Cube"
    goal_publisher.publish(goal)

goal.pose.position.x = 10
goal.pose.position.y = 0
goal.pose.position.z = 1

for z in range(3, 7, 1):
    goal.pose.position.z = goal.pose.position.z  + z/2
    for x in range(3, 7, 1):  
        goal.pose.position.x = 10
        goal.pose.position.x = goal.pose.position.x  + x +1
        for y in range(3, 7, 1):   
            goal.pose.position.y = 0
            goal.pose.position.y = goal.pose.position.y  + y  +1
            rospy.sleep(0.20)
            goal.header.frame_id = "Cube"
            goal_publisher.publish(goal)

rospy.spin()
